# status display function
status() {
	echo
	echo "==="
	echo "$1…"
}
